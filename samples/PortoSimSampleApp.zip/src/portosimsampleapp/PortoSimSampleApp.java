/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package portosimsampleapp;

import java.io.FileReader;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import money.portosim.Backtest;
import money.portosim.containers.sources.CSVPriceSource;
import money.portosim.strategies.FixedAllocation;

/**
 *
 * @author yarro
 */
public class PortoSimSampleApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        var sp500GoldMonthlyCSV = "sp500_gold_3yr_monthly.csv";
        
        // Load prices from a CSV file
        var prices = new CSVPriceSource(new FileReader(sp500GoldMonthlyCSV));
        
        // Then define a fixed allocation 70% stocks / 30% gold portfolio
        var fixedAlloc = new FixedAllocation(Map.of("SP500TR", 0.7, "GOLD", 0.3));
        
        // Build a backtest with a rebalancing period of one year
        var result = Backtest.withStrategy(fixedAlloc)
                .setRebalancePeriod(ChronoUnit.YEARS)   // rebalance every year
                .run(prices);   // test on the historic prices
        
        System.out.println("Total return is " + result.full().totalReturn());   
    }
    
}
