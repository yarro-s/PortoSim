/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package portosimsampleapp;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import money.portosim.BacktestBuilder;
import money.portosim.containers.readers.CSVPriceSeriesReader;
import money.portosim.strategies.FixedAllocation;

/**
 *
 * @author yarro
 */
public class PortoSimSampleApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        final String sp500GoldMonthlyCSV = "sp500_gold_3yr_monthly.csv";

        // Load prices from a CSV file
        var priceReader = new CSVPriceSeriesReader(new FileReader(sp500GoldMonthlyCSV));
        var prices = priceReader.readPrices();
        
        // Define a constant allocation portfolio
        var myStrategy = new FixedAllocation(Map.of("SP500TR", 0.7, "GOLD", 0.3));
        
        // Build a backtest
        var result = new BacktestBuilder()
                .setStrategy(myStrategy)
                .setRebalancePeriod(ChronoUnit.YEARS)   // rebalance every year
                .setPrices(prices)    // test on the historic prices
                .run();
        
        System.out.println("Total return is " + result.totalReturn().orElse(0));    
    }
    
}
